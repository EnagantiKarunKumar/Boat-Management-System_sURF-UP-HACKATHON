<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
		
					<li><a href="#"><i class="fa fa-desktop"></i> Boats</a>
					<ul>
						<li><a href="create-room.php">Add a Boat</a></li>
						<li><a href="manage-rooms.php">Manage Boats</a></li>
					</ul>
				</li>


				<li><a href="manage-students.php"><i class="fa fa-users"></i>Manage Clients</a></li>
				

			
		</nav>